// ============================================================================
// CLOUDFLARE WORKER - YouTube Audio Downloader
// ============================================================================
// Downloads audio from YouTube videos and converts to MP3
// Runs on Cloudflare's free tier (100k requests/day)
// ============================================================================

export default {
  async fetch(request, env) {
    // Handle CORS preflight
    if (request.method === 'OPTIONS') {
      return handleCORS();
    }

    try {
      const url = new URL(request.url);
      const path = url.pathname;

      // Route: /api/youtube/search
      if (path === '/api/youtube/search') {
        return await handleYouTubeSearch(url, env);
      }

      // Route: /api/youtube/download
      if (path === '/api/youtube/download') {
        return await handleYouTubeDownload(url, env);
      }

      // Route: /api/youtube/info
      if (path === '/api/youtube/info') {
        return await handleYouTubeInfo(url, env);
      }

      return jsonResponse({ error: 'Not found' }, 404);

    } catch (error) {
      console.error('Worker error:', error);
      return jsonResponse({ 
        error: 'Internal server error', 
        message: error.message 
      }, 500);
    }
  }
};

/**
 * Search YouTube for videos
 * GET /api/youtube/search?q=grateful+dead+althea
 */
async function handleYouTubeSearch(url, env) {
  const query = url.searchParams.get('q');
  
  if (!query) {
    return jsonResponse({ error: 'Missing query parameter' }, 400);
  }

  // YouTube Data API v3
  const apiKey = env.YOUTUBE_API_KEY; // Set in Cloudflare dashboard
  const searchUrl = `https://www.googleapis.com/youtube/v3/search?` +
    `part=snippet&q=${encodeURIComponent(query)}&` +
    `type=video&videoCategoryId=10&maxResults=10&key=${apiKey}`;

  const response = await fetch(searchUrl);
  const data = await response.json();

  if (!response.ok) {
    return jsonResponse({ 
      error: 'YouTube API error', 
      details: data 
    }, response.status);
  }

  // Format results
  const results = data.items.map(item => ({
    videoId: item.id.videoId,
    title: item.snippet.title,
    channel: item.snippet.channelTitle,
    thumbnail: item.snippet.thumbnails.medium.url,
    publishedAt: item.snippet.publishedAt,
    url: `https://www.youtube.com/watch?v=${item.id.videoId}`
  }));

  return jsonResponse({ results });
}

/**
 * Get video info (duration, format, etc.)
 * GET /api/youtube/info?videoId=abc123
 */
async function handleYouTubeInfo(url, env) {
  const videoId = url.searchParams.get('videoId');
  
  if (!videoId) {
    return jsonResponse({ error: 'Missing videoId parameter' }, 400);
  }

  // Use yt-dlp API endpoint (you'd need to host this separately)
  // For now, return mock data with estimated duration
  
  // Alternative: Use YouTube Data API to get duration
  const apiKey = env.YOUTUBE_API_KEY;
  const infoUrl = `https://www.googleapis.com/youtube/v3/videos?` +
    `part=contentDetails,snippet&id=${videoId}&key=${apiKey}`;

  const response = await fetch(infoUrl);
  const data = await response.json();

  if (!response.ok || !data.items || data.items.length === 0) {
    return jsonResponse({ error: 'Video not found' }, 404);
  }

  const video = data.items[0];
  const duration = parseDuration(video.contentDetails.duration);

  return jsonResponse({
    videoId,
    title: video.snippet.title,
    duration: duration, // in seconds
    durationFormatted: formatDuration(duration),
    thumbnail: video.snippet.thumbnails.high.url
  });
}

/**
 * Download audio from YouTube video
 * GET /api/youtube/download?videoId=abc123
 * 
 * NOTE: This requires a yt-dlp backend service
 * Cloudflare Workers can't run yt-dlp directly
 * Options:
 *   1. Host yt-dlp on separate server (Railway, Render)
 *   2. Use a third-party API like youtube-dl-api
 *   3. Use Cloudflare Workers with R2 storage for caching
 */
async function handleYouTubeDownload(url, env) {
  const videoId = url.searchParams.get('videoId');
  
  if (!videoId) {
    return jsonResponse({ error: 'Missing videoId parameter' }, 400);
  }

  // Option 1: Redirect to hosted yt-dlp service
  // You'd deploy a simple yt-dlp API server (see youtube-dl-server.py)
  const ytDlpServer = env.YTDLP_SERVER_URL || 'http://localhost:8080';
  const downloadUrl = `${ytDlpServer}/download?videoId=${videoId}&format=mp3`;
  
  return Response.redirect(downloadUrl, 302);
  
  // Option 2: Stream through worker (requires external service)
  /*
  const response = await fetch(downloadUrl);
  return new Response(response.body, {
    headers: {
      'Content-Type': 'audio/mpeg',
      'Content-Disposition': `attachment; filename="${videoId}.mp3"`,
      'Access-Control-Allow-Origin': '*'
    }
  });
  */
}

/**
 * Parse ISO 8601 duration (PT1H2M3S) to seconds
 */
function parseDuration(isoDuration) {
  const match = isoDuration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  
  if (!match) return 0;
  
  const hours = parseInt(match[1] || 0);
  const minutes = parseInt(match[2] || 0);
  const seconds = parseInt(match[3] || 0);
  
  return hours * 3600 + minutes * 60 + seconds;
}

/**
 * Format seconds to HH:MM:SS
 */
function formatDuration(seconds) {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
  return `${minutes}:${String(secs).padStart(2, '0')}`;
}

/**
 * JSON response helper
 */
function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    }
  });
}

/**
 * Handle CORS preflight
 */
function handleCORS() {
  return new Response(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400'
    }
  });
}
